
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class EmployeeServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("id");
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "your_user", "your_password");
            Statement stmt = conn.createStatement();
            ResultSet rs;
            if (id != null && !id.isEmpty()) {
                rs = stmt.executeQuery("SELECT * FROM Employee WHERE EmpID=" + id);
            } else {
                rs = stmt.executeQuery("SELECT * FROM Employee");
            }

            while (rs.next()) {
                out.println("<p>" + rs.getInt("EmpID") + " " + rs.getString("Name") + " " + rs.getDouble("Salary") + "</p>");
            }
            conn.close();
        } catch (Exception e) {
            out.println("Error: " + e.getMessage());
        }
    }
}
