
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class AttendanceServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String studentID = request.getParameter("studentID");
        String name = request.getParameter("name");
        String attendance = request.getParameter("attendance");
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/your_database", "your_user", "your_password");
            PreparedStatement ps = conn.prepareStatement("INSERT INTO Attendance (StudentID, Name, Attendance) VALUES (?, ?, ?)");
            ps.setString(1, studentID);
            ps.setString(2, name);
            ps.setString(3, attendance);
            ps.executeUpdate();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<h1>Attendance Submitted!</h1>");
    }
}
